import json
import tempfile
import unittest
from pathlib import Path

from config import CopyTradingConfig, load_config


EXPECTED_WALLETS = [
    "HmBmSYwYEgEZuBUYuDs9xofyqBAkw4ywugB1d7R7sTGh",
    "78N177fzNJpp8pG49xDv1efYcTMSzo9tPTKEA9mAVkh2",
    "Bi4rd5FH5bYEN8scZ7wevxNZyNmKHdaBcvewdPFxYdLt",
]


class CopyConfigTests(unittest.TestCase):
    def test_copy_defaults_to_solana_and_selected_wallets(self):
        cfg = CopyTradingConfig()
        self.assertEqual(cfg.chain, "sol")
        self.assertEqual(cfg.paper_trade_usdt, 500.0)
        self.assertEqual(cfg.max_positions, 6)
        self.assertEqual(cfg.source_wallets, EXPECTED_WALLETS)

    def test_untouched_v180_copy_block_migrates_to_solana(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "settings.json"
            path.write_text(json.dumps({
                "trading": {"version": "1.8.0"},
                "copy": {"chain": "eth", "enabled": True, "paper_only": True,
                         "paper_trade_usdt": 500.0, "max_positions": 6, "source_wallets": []},
            }), encoding="utf-8")
            cfg = load_config(path)
            self.assertEqual(cfg.trading.version, "1.8.2")
            self.assertEqual(cfg.copy.chain, "sol")
            self.assertEqual(cfg.copy.source_wallets, EXPECTED_WALLETS)


if __name__ == "__main__":
    unittest.main()
