import unittest
from datetime import datetime, timezone
from types import SimpleNamespace

from config import AppConfig
from governor import PortfolioGovernor, Proposal
from intelligence import NewsItem, build_state, classify_item, parse_rss


class IntelligenceTests(unittest.TestCase):
    def test_rss_parser_reads_item(self):
        xml=b'''<?xml version="1.0"?><rss><channel><item><title>Solana network upgrade launches</title><link>https://example.com/a</link><pubDate>Tue, 22 Sep 2026 08:00:00 GMT</pubDate><description>Major protocol upgrade for Solana.</description></item></channel></rss>'''
        rows=parse_rss(xml,"COINDESK")
        self.assertEqual(len(rows),1)
        self.assertTrue(rows[0].title.startswith("Solana"))
        self.assertEqual(rows[0].url,"https://example.com/a")

    def test_security_incident_is_bearish_and_critical(self):
        now=datetime(2026,9,22,10,0,tzinfo=timezone.utc)
        item=NewsItem("COINDESK","Solana exploit drains protocol funds","https://x",now.isoformat(),"")
        e=classify_item(item,now)
        self.assertIsNotNone(e)
        self.assertEqual(e["category"],"SECURITY_INCIDENT")
        self.assertEqual(e["direction"],-1)
        self.assertTrue(e["critical"])
        self.assertIn("SOL",e["assets"])

    def test_listing_is_bullish_day_event(self):
        now=datetime(2026,9,22,10,0,tzinfo=timezone.utc)
        item=NewsItem("BINANCE","Binance will list AAVE new trading pair","https://x",now.isoformat(),"")
        e=classify_item(item,now)
        self.assertIsNotNone(e)
        self.assertEqual(e["category"],"LISTING")
        self.assertEqual(e["direction"],1)
        self.assertEqual(e["horizon"],"DAY")
        self.assertIn("AAVE",e["assets"])

    def test_two_sources_raise_corroboration_and_asset_state(self):
        now=datetime(2026,9,22,10,0,tzinfo=timezone.utc)
        items=[
            NewsItem("COINDESK","Solana network halt after outage","https://a",now.isoformat(),""),
            NewsItem("GDELT","Solana outage leaves network halted","https://b",now.isoformat(),""),
        ]
        state=build_state(items,{"COINDESK":"CONNECTED (1)","GDELT":"CONNECTED (1)"},now)
        sol=next(a for a in state["assets"] if a["symbol"]=="SOL")
        self.assertEqual(state["status"],"ACTIVE")
        self.assertEqual(sol["bias"],"BEARISH")
        self.assertGreater(sol["confidence"],60)
        self.assertTrue(state["critical_risk"].startswith("SOL"))

    def _plan(self,symbol="SOLUSDT",direction="LONG",score=75.0):
        return SimpleNamespace(symbol=symbol,direction=direction,score=score,net_rr=2.0,stop_pct=2.0)

    def test_governor_intelligence_adjusts_rank_but_does_not_create_trade(self):
        cfg=AppConfig(); gov=PortfolioGovernor(cfg)
        state={"status":"ACTIVE","last_update":datetime.now(timezone.utc).isoformat(),"bias":"NEUTRAL","impact":0,"confidence":0,
               "assets":[{"symbol":"SOL","score":80,"bias":"BULLISH","impact":90,"confidence":90,"horizon":"DAY"}],"critical_blocks":[]}
        ranked=gov.rank([self._plan()],[],state)
        self.assertEqual(len(ranked),1)
        self.assertGreater(ranked[0].intelligence_adjustment,0)
        self.assertLessEqual(ranked[0].intelligence_adjustment,cfg.intelligence.max_governor_adjustment_points)
        self.assertEqual(gov.rank([],[],state),[])

    def test_critical_bearish_intel_can_block_new_long_only(self):
        cfg=AppConfig(); gov=PortfolioGovernor(cfg)
        state={"status":"ACTIVE","last_update":datetime.now(timezone.utc).isoformat(),
               "critical_blocks":[{"symbol":"SOL","direction":"BEARISH","category":"SECURITY_INCIDENT","impact":95,"confidence":90}]}
        longp=Proposal("DAY","SOLUSDT","LONG",75,2.0,2.0,self._plan())
        shortp=Proposal("DAY","SOLUSDT","SHORT",75,2.0,2.0,self._plan(direction="SHORT"))
        ok,why=gov.intelligence_allow(longp,state)
        self.assertFalse(ok); self.assertIn("CRITICAL INTEL",why)
        ok,_=gov.intelligence_allow(shortp,state)
        self.assertTrue(ok)

if __name__=='__main__': unittest.main()
