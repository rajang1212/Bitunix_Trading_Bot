import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from config import AppConfig
from daytrader import _breadth_momentum, _correlation_guard
from indicators import Candle
from store import DayTraderStore
from strategy import TradePlan


def candles_from_returns(returns, start=100.0):
    out = []
    p = start
    t0 = 1_700_000_000_000
    for i, r in enumerate(returns):
        o = p
        c = p * (1 + r)
        out.append(Candle(o, max(o, c) * 1.001, min(o, c) * 0.999, c, 1000, 100000, t0 + i * 900_000))
        p = c
    return out


class AdaptiveHelpersTests(unittest.TestCase):
    def test_breadth_history_detects_fast_fall(self):
        cfg = AppConfig()
        with tempfile.TemporaryDirectory() as td:
            store = DayTraderStore(Path(td) / "x.sqlite3")
            try:
                base = 1_700_000_000_000
                vals = [0.90, 0.85, 0.80, 0.72, 0.60]
                result = None
                for i, v in enumerate(vals):
                    result = _breadth_momentum(store, v, base + i * 900_000, cfg)
                self.assertIsNotNone(result)
                _, d1h, state = result
                self.assertLessEqual(d1h, -0.20)
                self.assertEqual(state, "FALLING_FAST")
            finally:
                store.close()

    def test_correlation_cap_blocks_third_similar_long(self):
        cfg = AppConfig()
        cfg.trading.high_correlation_threshold = 0.80
        cfg.trading.max_highly_correlated_positions = 2
        rets = [0.001, -0.0005, 0.0015, 0.0008, -0.0003, 0.0012, 0.0004, -0.0002, 0.0011, 0.0007] * 4
        cache = {
            "NEWUSDT": {"c15": candles_from_returns(rets)},
            "AUSDT": {"c15": candles_from_returns(rets)},
            "BUSDT": {"c15": candles_from_returns([x * 1.01 for x in rets])},
        }
        active = [
            {"symbol": "AUSDT", "direction": "LONG"},
            {"symbol": "BUSDT", "direction": "LONG"},
        ]
        plan = TradePlan(
            symbol="NEWUSDT", direction="LONG", setup_type="BREAKOUT_RETEST", score=80.0,
            entry_price=100.0, stop_price=98.0, stop_pct=2.0, reference_target_price=105.0,
            partial_target_price=103.0, net_rr=2.0, regime="BULL", parent_structure="BULL",
            structure_1h="BULL", structure_30m="BULL", breadth_change_1h=0.0, features={}, reasons=[],
        )
        ok, reason = _correlation_guard(plan, active, cache, cfg)
        self.assertFalse(ok)
        self.assertIn("correlation cap", reason)


if __name__ == "__main__":
    unittest.main()
