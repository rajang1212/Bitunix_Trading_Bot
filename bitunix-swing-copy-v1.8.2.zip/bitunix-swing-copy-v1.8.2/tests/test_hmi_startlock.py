import unittest
from pathlib import Path

class HmiStartLockTests(unittest.TestCase):
    def test_start_button_is_locked_while_running(self):
        src=(Path(__file__).resolve().parents[1]/"hmi.py").read_text(encoding="utf-8")
        self.assertIn('self.start_btn.state(["disabled"])',src)
        self.assertIn('if running: self.start_btn.state(["disabled"])',src)
        self.assertIn('else: self.start_btn.state(["!disabled"])',src)

if __name__=='__main__': unittest.main()
