import tempfile
import unittest
from pathlib import Path

from capital_allocator import capital_state, proposal_margin_cap
from config import AppConfig
from store import DayTraderStore


def tr(ttype, margin):
    return {"trade_type": ttype, "margin_usdt": margin}


class WalletTests(unittest.TestCase):
    def setUp(self):
        self.cfg = AppConfig()

    def test_default_wallets(self):
        with tempfile.TemporaryDirectory() as td:
            st=DayTraderStore(Path(td)/"db.sqlite3")
            try:
                st.ensure_wallet(day_initial=2500,swing_initial=5000,reserve_initial=5000,legacy_flex_target="DAY")
                w=st.wallet_state()
                self.assertEqual(w["day_balance"],2500)
                self.assertEqual(w["swing_balance"],5000)
                self.assertEqual(w["copy_balance"],3000)
                self.assertEqual(w["reserve_balance"],5000)
                self.assertEqual(w["wallet_total"],15500)
            finally: st.close()

    def test_copy_wallet_is_capped_at_3000_and_transferable(self):
        with tempfile.TemporaryDirectory() as td:
            st=DayTraderStore(Path(td)/"db.sqlite3")
            try:
                st.ensure_wallet()
                st.transfer_wallet("COPY","RESERVE",1000)
                self.assertEqual(st.wallet_state()["copy_balance"],2000)
                st.transfer_wallet("RESERVE","COPY",1000,copy_max_balance=3000)
                self.assertEqual(st.wallet_state()["copy_balance"],3000)
                with self.assertRaises(ValueError):
                    st.transfer_wallet("SWING","COPY",1,copy_max_balance=3000)
            finally: st.close()

    def test_retired_day_allocation_moves_to_reserve_once(self):
        with tempfile.TemporaryDirectory() as td:
            st=DayTraderStore(Path(td)/"db.sqlite3")
            try:
                st.ensure_wallet(day_initial=2500,swing_initial=5000,reserve_initial=5000)
                self.assertEqual(st.retire_day_wallet_to_reserve(),2500)
                w=st.wallet_state()
                self.assertEqual(w["day_balance"],0)
                self.assertEqual(w["reserve_balance"],7500)
                self.assertEqual(st.retire_day_wallet_to_reserve(),0)
            finally: st.close()

    def test_v16_swing_flex_migrates_to_swing_account(self):
        with tempfile.TemporaryDirectory() as td:
            st=DayTraderStore(Path(td)/"db.sqlite3")
            try:
                st.ensure_wallet(day_initial=2500,swing_initial=5000,reserve_initial=5000,legacy_flex_target="SWING")
                w=st.wallet_state()
                self.assertEqual(w["day_balance"],0)
                self.assertEqual(w["swing_balance"],7500)
                self.assertEqual(w["reserve_balance"],5000)
            finally: st.close()

    def test_reserve_transfer_to_day_and_swing(self):
        with tempfile.TemporaryDirectory() as td:
            st=DayTraderStore(Path(td)/"db.sqlite3")
            try:
                st.ensure_wallet()
                st.transfer_wallet("RESERVE","DAY",700)
                st.transfer_wallet("RESERVE","SWING",300)
                w=st.wallet_state()
                self.assertEqual(w["reserve_balance"],4000)
                self.assertEqual(w["day_balance"],3200)
                self.assertEqual(w["swing_balance"],5300)
            finally: st.close()

    def test_trade_pnl_settles_to_reserve_once(self):
        with tempfile.TemporaryDirectory() as td:
            st=DayTraderStore(Path(td)/"db.sqlite3")
            try:
                st.ensure_wallet()
                self.assertTrue(st.settle_trade_to_reserve("T1",125.5))
                self.assertFalse(st.settle_trade_to_reserve("T1",125.5))
                self.assertAlmostEqual(st.wallet_state()["reserve_balance"],5125.5)
                self.assertTrue(st.settle_trade_to_reserve("T2",-80.0))
                self.assertAlmostEqual(st.wallet_state()["reserve_balance"],5045.5)
            finally: st.close()

    def test_capital_state_and_margin_caps(self):
        active=[tr("SWING",1000) for _ in range(4)] + [tr("DAY",500) for _ in range(2)]
        balances={"DAY":2500,"SWING":5000,"RESERVE":5000}
        s=capital_state(active,self.cfg,balances)
        self.assertEqual(s["day_new_available"],1500)
        self.assertEqual(s["swing_new_available"],1000)
        self.assertEqual(proposal_margin_cap("DAY",active,self.cfg,balances),500)
        self.assertEqual(proposal_margin_cap("SWING",active,self.cfg,balances),1000)

    def test_extra_swing_capital_can_raise_margin_cap_modestly(self):
        active=[]; balances={"DAY":2500,"SWING":10500,"RESERVE":2000}
        cap=proposal_margin_cap("SWING",active,self.cfg,balances)
        self.assertEqual(cap,1500)


if __name__ == "__main__":
    unittest.main()

class FixedStrategyTransferTests(unittest.TestCase):
    def _trade(self, cid: str, ttype: str, margin: float):
        return {
            "client_id": cid, "symbol": "TESTUSDT", "direction": "LONG", "status": "PAPER_OPEN",
            "opened_utc": "2026-09-23T00:00:00+00:00", "entry_price": 100.0, "stop_price": 98.0,
            "initial_stop_price": 98.0, "reference_target_price": 106.0, "partial_target_price": 104.0,
            "qty": margin*5/100.0, "initial_qty": margin*5/100.0, "remaining_fraction": 1.0,
            "leverage": 5, "margin_usdt": margin, "rule_score": 80.0, "setup_type": "TEST",
            "market_regime": "BULL", "features": {}, "reasons": [], "best_price": 100.0,
            "trade_type": ttype, "agent_name": ttype+"_AGENT", "notional_usdt": margin*5,
            "max_hold_minutes": 1440, "partial_take_profit_r": 2.0, "partial_fraction": 0.5,
            "runner_lock_r": 0.1, "strategy_version": "1.7.1",
        }

    def test_fixed_2500_transfer_moves_free_now_and_remainder_later(self):
        with tempfile.TemporaryDirectory() as td:
            st=DayTraderStore(Path(td)/"db.sqlite3")
            try:
                st.ensure_wallet(day_initial=2500,swing_initial=5000,reserve_initial=5000)
                st.insert_trade(self._trade("D1","DAY",1000))
                req=st.request_fixed_transfer("DAY","SWING",2500)
                self.assertAlmostEqual(req["transferred"],1500)
                self.assertAlmostEqual(req["remaining"],1000)
                st.update_trade("D1",status="PAPER_CLOSED",closed_utc="2026-09-23T01:00:00+00:00",remaining_fraction=0.0)
                req=st.process_fixed_transfer()
                self.assertAlmostEqual(req["remaining"],0)
                w=st.wallet_state()
                self.assertAlmostEqual(w["day_balance"],0)
                self.assertAlmostEqual(w["swing_balance"],7500)
            finally: st.close()

    def test_manual_exit_request_is_stored(self):
        with tempfile.TemporaryDirectory() as td:
            st=DayTraderStore(Path(td)/"db.sqlite3")
            try:
                st.ensure_wallet()
                st.insert_trade(self._trade("S1","SWING",1000))
                st.set_manual_exit("S1","LIMIT",110.0)
                tr=st.active_trade("S1")
                self.assertEqual(tr["manual_exit_type"],"LIMIT")
                self.assertEqual(tr["manual_exit_limit_price"],110.0)
                st.set_manual_exit("S1","MARKET")
                tr=st.active_trade("S1")
                self.assertEqual(tr["manual_exit_type"],"MARKET")
                self.assertIsNone(tr["manual_exit_limit_price"])
            finally: st.close()

class SwingCorePreservationTests(unittest.TestCase):
    def test_fixed_swing_to_day_preserves_5000_core(self):
        with tempfile.TemporaryDirectory() as td:
            st=DayTraderStore(Path(td)/"db.sqlite3")
            try:
                st.ensure_wallet(day_initial=0,swing_initial=7500,reserve_initial=5000)
                req=st.request_fixed_transfer("SWING","DAY",2500,source_floor=5000)
                self.assertAlmostEqual(req["remaining"],0)
                w=st.wallet_state()
                self.assertAlmostEqual(w["swing_balance"],5000)
                self.assertAlmostEqual(w["day_balance"],2500)
            finally: st.close()
