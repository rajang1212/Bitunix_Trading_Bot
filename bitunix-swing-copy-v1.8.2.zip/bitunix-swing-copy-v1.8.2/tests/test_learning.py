import json
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from config import AppConfig
from indicators import Candle
from learning import _purged_split, resolve_labels
from store import DayTraderStore
from strategy import FEATURE_NAMES


class LearningTests(unittest.TestCase):
    def test_purged_split_is_time_ordered(self):
        cfg = AppConfig().learning
        # 300 unique 15m timestamps, duplicated for long/short.
        base = 1_700_000_000_000
        times = []
        for i in range(300):
            times.extend([base + i * 900_000] * 2)
        arr = np.asarray(times, dtype=np.int64)
        train, test, cutoff = _purged_split(arr, cfg)
        self.assertIsNotNone(cutoff)
        self.assertTrue(np.max(arr[train]) < np.min(arr[test]))
        self.assertGreater(np.sum(train), 0)
        self.assertGreater(np.sum(test), 0)

    def test_labeler_marks_target_before_stop(self):
        cfg = AppConfig().learning
        with tempfile.TemporaryDirectory() as td:
            store = DayTraderStore(Path(td) / "x.sqlite3")
            try:
                t0 = 1_700_000_000_000
                features = {k: 0.0 for k in FEATURE_NAMES}
                sid = store.insert_snapshot(
                    candle_time_ms=t0, symbol="TESTUSDT", price=100.0, spread_pct=0.02,
                    btc_regime="BULL", breadth_1h=0.7, breadth_4h=0.6,
                    rule_long_score=70, rule_short_score=30, best_direction="LONG",
                    best_setup="TREND_PULLBACK", features={}, ai=None,
                )
                store.insert_learning_example(
                    snapshot_id=sid, symbol="TESTUSDT", direction="LONG", candle_time_ms=t0,
                    entry_price=100.0, stop_pct=1.0, target_r=2.0, rule_score=70,
                    setup_type="TREND_PULLBACK", features=features,
                )
                bars = []
                p = 100.0
                for i in range(96):
                    # Target 102 is reached early, stop 99 is never touched.
                    close = min(102.4, 100.0 + 0.04 * (i + 1))
                    high = close + (0.1 if i < 40 else 0.2)
                    low = max(99.4, p - 0.05)
                    bars.append(Candle(p, high, low, close, 1000, 100000, t0 + (i + 1) * 900_000))
                    p = close
                store.upsert_bars("TESTUSDT", "15m", bars)
                result = resolve_labels(store, cfg, now_ms=t0 + cfg.label_horizon_minutes * 60_000 + 1)
                self.assertEqual(result["resolved"], 1)
                row = store.labeled_examples()[0]
                self.assertEqual(row["target_hit"], 1)
                self.assertEqual(row["first_hit"], "TARGET")
                self.assertAlmostEqual(row["outcome_r"], 2.0)
            finally:
                store.close()


if __name__ == "__main__":
    unittest.main()

class TrainingLoopTests(unittest.TestCase):
    def test_daily_learning_trains_neural_and_benchmarks(self):
        from learning import run_daily_learning, ShadowPredictor
        from datetime import datetime, timezone
        cfg = AppConfig()
        cfg.learning.min_train_examples = 80
        cfg.learning.min_test_examples = 40
        cfg.learning.purge_minutes = 180
        cfg.learning.mlp_max_iter = 80
        cfg.learning.mlp_hidden_layers = [16, 8]
        cfg.learning.hgb_max_iter = 30
        with tempfile.TemporaryDirectory() as td:
            d = Path(td)
            store = DayTraderStore(d / "daytrader.sqlite3")
            try:
                base = 1_700_000_000_000
                for i in range(140):
                    sid = store.insert_snapshot(
                        candle_time_ms=base + i * 900_000, symbol=f"S{i%5}USDT", price=100.0,
                        spread_pct=0.02, btc_regime="BULL", breadth_1h=0.6, breadth_4h=0.6,
                        rule_long_score=70, rule_short_score=55, best_direction="LONG", best_setup="TREND_PULLBACK",
                        features={}, ai=None,
                    )
                    for direction in ("LONG", "SHORT"):
                        f = {k: 0.0 for k in FEATURE_NAMES}
                        signal = 1.0 if (i % 4 in (0, 1)) else -1.0
                        f["dir_relative_strength_btc_1h"] = signal if direction == "LONG" else -signal
                        f["rule_score"] = 75.0 if signal > 0 else 55.0
                        store.insert_learning_example(
                            snapshot_id=sid, symbol=f"S{i%5}USDT", direction=direction,
                            candle_time_ms=base + i * 900_000, entry_price=100.0, stop_pct=1.0,
                            target_r=2.0, rule_score=f["rule_score"], setup_type="TREND_PULLBACK", features=f,
                        )
                rows = store.db.execute("SELECT id,direction,features_json FROM learning_examples ORDER BY id").fetchall()
                for row in rows:
                    f = json.loads(row["features_json"])
                    hit = f["dir_relative_strength_btc_1h"] > 0
                    store.resolve_learning_example(
                        int(row["id"]), target_hit=hit, stop_hit=not hit, first_hit="TARGET" if hit else "STOP",
                        mfe_r=2.0 if hit else 0.2, mae_r=0.2 if hit else 1.0,
                        terminal_r=2.0 if hit else -1.0, outcome_r=2.0 if hit else -1.0,
                    )
            finally:
                store.close()
            result = run_daily_learning(d, cfg, force=True)
            self.assertEqual(result["status"], "TESTED")
            names = {m["model_name"] for m in result["models"]}
            self.assertIn("NEURAL_MLP", names)
            self.assertIn("HIST_GRADIENT_BOOST", names)
            self.assertTrue((d / "models" / "shadow_champion.json").exists())
            predictor = ShadowPredictor(d)
            f = {k: 0.0 for k in FEATURE_NAMES}
            pred = predictor.predict(f)
            self.assertIsNotNone(pred)
            self.assertEqual(pred["authority"], "SHADOW_ONLY")
