import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import runtime_control
from hmi_data import _pa_label, _perf


class HmiDataTests(unittest.TestCase):
    def test_pa_labels_are_human_readable(self):
        self.assertEqual(_pa_label('TREND_PULLBACK'), 'Trend Pullback')
        self.assertEqual(_pa_label('SWING_BREAKOUT_RETEST'), 'Breakout Retest')
        self.assertEqual(_pa_label(None), 'None')

    def test_performance_summary(self):
        rows=[{'net_pnl':100},{'net_pnl':-40},{'net_pnl':20}]
        x=_perf(rows,4)
        self.assertEqual(x['opened'],4)
        self.assertEqual(x['closed'],3)
        self.assertEqual(x['wins'],2)
        self.assertEqual(x['losses'],1)
        self.assertAlmostEqual(x['net'],80)
        self.assertAlmostEqual(x['profit_factor'],3.0)


class RuntimeControlTests(unittest.TestCase):
    def test_pause_and_stop_control_roundtrip(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            with patch.object(runtime_control,'data_directory',return_value=root):
                c=runtime_control.write_control(pause_new_trades=True,stop_requested=False)
                self.assertTrue(c['pause_new_trades'])
                self.assertFalse(c['stop_requested'])
                c=runtime_control.request_stop()
                self.assertTrue(c['stop_requested'])
                c=runtime_control.prepare_start()
                self.assertFalse(c['stop_requested'])
                self.assertTrue(c['pause_new_trades'])

    def test_pid_file_roundtrip(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            with patch.object(runtime_control,'data_directory',return_value=root):
                runtime_control.write_pid(12345)
                self.assertEqual(runtime_control.read_pid(),12345)
                runtime_control.clear_pid(12345)
                self.assertIsNone(runtime_control.read_pid())


if __name__=='__main__':
    unittest.main()

class ManualExitDisplayTests(unittest.TestCase):
    def test_position_rows_show_pending_limit(self):
        from config import AppConfig
        from store import DayTraderStore
        from hmi_data import position_rows
        with tempfile.TemporaryDirectory() as td:
            st=DayTraderStore(Path(td)/"db.sqlite3")
            try:
                st.insert_trade({
                    "client_id":"M1","symbol":"BTCUSDT","direction":"LONG","status":"PAPER_OPEN",
                    "opened_utc":"2026-09-23T00:00:00+00:00","entry_price":100.0,"stop_price":98.0,"initial_stop_price":98.0,
                    "reference_target_price":106.0,"partial_target_price":104.0,"qty":25.0,"initial_qty":25.0,"remaining_fraction":1.0,
                    "leverage":5,"margin_usdt":500.0,"rule_score":80.0,"setup_type":"TEST","market_regime":"BULL","features":{},"reasons":[],
                    "best_price":100.0,"trade_type":"DAY","agent_name":"DAY_AGENT","notional_usdt":2500.0,"max_hold_minutes":1440,
                    "partial_take_profit_r":2.0,"partial_fraction":0.5,"runner_lock_r":0.1,"strategy_version":"1.7.1"
                })
                st.set_manual_exit("M1","LIMIT",110.0)
                rows=position_rows(st,AppConfig(),{"BTCUSDT":105.0})
                self.assertIn("LIMIT CLOSE",rows[0]["status"])
            finally: st.close()
