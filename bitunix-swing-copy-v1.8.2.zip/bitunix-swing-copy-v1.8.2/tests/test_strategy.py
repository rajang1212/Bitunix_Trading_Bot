import math
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from config import AppConfig
from indicators import Candle
from strategy import evaluate_symbol, build_trade_plan, select_top_symbols


def trend_candles(n, start=100.0, step=0.25, interval_ms=900_000, start_ms=1_700_000_000_000):
    out = []
    p = start
    for i in range(n):
        o = p
        c = p + step
        h = max(o, c) + abs(step) * 0.7 + 0.08
        l = min(o, c) - abs(step) * 0.7 - 0.08
        out.append(Candle(o, h, l, c, 1000 + i, 100000 + i * 100, start_ms + i * interval_ms))
        p = c
    return out


def compression_breakout_15m(n=80):
    out = trend_candles(n - 19, start=100, step=0.15)
    p = out[-1].close
    base_ms = out[-1].time_ms + 900_000
    # 12 wider bars, rising slowly.
    for i in range(12):
        o = p
        c = p + 0.05
        out.append(Candle(o, c + 0.40, o - 0.35, c, 1200, 120000, base_ms + i * 900_000))
        p = c
    # Six compressed bars.
    for i in range(6):
        o = p
        c = p + 0.015
        out.append(Candle(o, c + 0.07, o - 0.06, c, 900, 90000, base_ms + (12 + i) * 900_000))
        p = c
    box_high = max(c.high for c in out[-6:])
    o = p
    c = box_high + 0.35
    out.append(Candle(o, c + 0.12, o - 0.05, c, 2400, 250000, base_ms + 18 * 900_000))
    return out




def compression_breakout_15m_short(n=80):
    out = trend_candles(n - 19, start=120, step=-0.15)
    p = out[-1].close
    base_ms = out[-1].time_ms + 900_000
    for i in range(12):
        o = p
        c = p - 0.05
        out.append(Candle(o, o + 0.35, c - 0.40, c, 1200, 120000, base_ms + i * 900_000))
        p = c
    for i in range(6):
        o = p
        c = p - 0.015
        out.append(Candle(o, o + 0.06, c - 0.07, c, 900, 90000, base_ms + (12 + i) * 900_000))
        p = c
    box_low = min(c.low for c in out[-6:])
    o = p
    c = box_low - 0.35
    out.append(Candle(o, o + 0.05, c - 0.12, c, 2400, 250000, base_ms + 18 * 900_000))
    return out
class StrategyTests(unittest.TestCase):
    def test_select_top_symbols_excludes_non_crypto(self):
        cfg = AppConfig().trading
        contracts = [
            {"symbol": "BTCUSDT", "quote": "USDT", "symbolStatus": "OPEN", "isApiSupported": True, "maxLeverage": 100, "base": "BTC"},
            {"symbol": "XAUTUSDT", "quote": "USDT", "symbolStatus": "OPEN", "isApiSupported": True, "maxLeverage": 50, "base": "XAUT"},
            {"symbol": "ETHUSDT", "quote": "USDT", "symbolStatus": "OPEN", "isApiSupported": True, "maxLeverage": 100, "base": "ETH"},
        ]
        tickers = [
            {"symbol": "XAUTUSDT", "quoteVol": 900_000_000},
            {"symbol": "BTCUSDT", "quoteVol": 800_000_000},
            {"symbol": "ETHUSDT", "quoteVol": 700_000_000},
        ]
        self.assertEqual(select_top_symbols(contracts, tickers, cfg), ["BTCUSDT", "ETHUSDT"])

    def test_daytrade_candidate_can_actually_qualify(self):
        cfg = AppConfig().trading
        c5 = trend_candles(100, 100, 0.05, 300_000)
        c15 = compression_breakout_15m(80)
        c30 = trend_candles(100, 90, 0.18, 1_800_000)
        c1h = trend_candles(100, 80, 0.30, 3_600_000)
        c4h = trend_candles(80, 60, 0.70, 14_400_000)
        price = c15[-1].close
        btc_features = {
            "ret_1h_1": 0.2, "ret_1h_4": 0.8, "ret_4h_1": 0.5,
            "ema20_gap_1h_pct": 0.4, "ema50_gap_4h_pct": 1.0,
            "ema20_slope_4h_pct": 0.2, "atr_15m_pct": 0.4, "adx_1h": 30,
        }
        ev = evaluate_symbol(
            "SOLUSDT", c5=c5, c15=c15, c30=c30, c1h=c1h, c4h=c4h,
            bid=price * 0.9998, ask=price * 1.0002, funding_8h=0.0001, book_bid_share=0.55,
            btc_features=btc_features, regime="BULL", breadth_1h=0.75, breadth_4h=0.70,
            universe_return_1h=0.1, universe_return_4h=0.4, cfg=cfg, btc_shock=False,
        )
        self.assertGreaterEqual(ev.long.score, cfg.minimum_rule_score)
        self.assertEqual(ev.long.setup_type, "COMPRESSION_BREAKOUT")
        self.assertFalse(ev.long.hard_blockers, ev.long.hard_blockers)
        plan = build_trade_plan(ev, cfg)
        self.assertIsNotNone(plan)
        self.assertEqual(plan.direction, "LONG")

    def test_bear_parent_blocks_long_even_in_strong_bull_market(self):
        cfg = AppConfig().trading
        c5 = trend_candles(100, 120, -0.04, 300_000)
        c15 = trend_candles(100, 120, -0.10, 900_000)
        c30 = trend_candles(100, 130, -0.16, 1_800_000)
        c1h = trend_candles(100, 150, -0.28, 3_600_000)
        c4h = trend_candles(80, 180, -0.55, 14_400_000)
        price = c15[-1].close
        btc_features = {
            "ret_1h_1": 0.4, "ret_1h_4": 1.0, "ret_4h_1": 0.8,
            "ema20_gap_1h_pct": 0.7, "ema50_gap_4h_pct": 1.3,
            "ema20_slope_4h_pct": 0.3, "atr_15m_pct": 0.4, "adx_1h": 35,
        }
        ev = evaluate_symbol(
            "NEARUSDT", c5=c5, c15=c15, c30=c30, c1h=c1h, c4h=c4h,
            bid=price * 0.9998, ask=price * 1.0002, funding_8h=0.0, book_bid_share=0.5,
            btc_features=btc_features, regime="STRONG_BULL", breadth_1h=0.95, breadth_4h=1.0,
            universe_return_1h=0.5, universe_return_4h=1.0, cfg=cfg, btc_shock=False,
        )
        self.assertEqual(ev.parent_structure, "BEAR")
        self.assertTrue(any("countertrend LONG" in x for x in ev.long.hard_blockers), ev.long.hard_blockers)

    def test_short_candidate_can_actually_qualify(self):
        cfg = AppConfig().trading
        c5 = trend_candles(100, 120, -0.05, 300_000)
        c15 = compression_breakout_15m_short(80)
        c30 = trend_candles(100, 130, -0.18, 1_800_000)
        c1h = trend_candles(100, 150, -0.30, 3_600_000)
        c4h = trend_candles(80, 180, -0.70, 14_400_000)
        price = c15[-1].close
        btc_features = {
            "ret_1h_1": -0.2, "ret_1h_4": -0.8, "ret_4h_1": -0.5,
            "ema20_gap_1h_pct": -0.4, "ema50_gap_4h_pct": -1.0,
            "ema20_slope_4h_pct": -0.2, "atr_15m_pct": 0.4, "adx_1h": 30,
        }
        ev = evaluate_symbol(
            "ETHUSDT", c5=c5, c15=c15, c30=c30, c1h=c1h, c4h=c4h,
            bid=price * 0.9998, ask=price * 1.0002, funding_8h=0.0, book_bid_share=0.45,
            btc_features=btc_features, regime="BEAR", breadth_1h=0.25, breadth_4h=0.30,
            universe_return_1h=-0.1, universe_return_4h=-0.4, cfg=cfg,
            breadth_change_15m=-0.03, breadth_change_1h=-0.10, breadth_state="FALLING",
            btc_shock=False,
        )
        self.assertGreaterEqual(ev.short.score, cfg.minimum_rule_score)
        self.assertFalse(ev.short.hard_blockers, ev.short.hard_blockers)
        plan = build_trade_plan(ev, cfg)
        self.assertIsNotNone(plan)
        self.assertEqual(plan.direction, "SHORT")

    def test_pullback_requires_established_parent_trend(self):
        cfg = AppConfig().trading
        c5 = trend_candles(100, 100, 0.02, 300_000)
        c15 = trend_candles(100, 100, 0.02, 900_000)
        c30 = trend_candles(100, 100, 0.01, 1_800_000)
        c1h = trend_candles(100, 100, 0.005, 3_600_000)
        c4h = trend_candles(80, 100, -0.005, 14_400_000)
        price = c15[-1].close
        btc_features = {"ret_1h_1": 0.1, "ret_1h_4": 0.2, "ema20_gap_1h_pct": 0.1, "ema50_gap_4h_pct": 0.1, "atr_15m_pct": 0.3, "adx_1h": 20}
        ev = evaluate_symbol(
            "XRPUSDT", c5=c5, c15=c15, c30=c30, c1h=c1h, c4h=c4h,
            bid=price * 0.9998, ask=price * 1.0002, funding_8h=0.0, book_bid_share=0.5,
            btc_features=btc_features, regime="BULL", breadth_1h=0.7, breadth_4h=0.6,
            universe_return_1h=0.0, universe_return_4h=0.0, cfg=cfg, btc_shock=False,
        )
        if ev.parent_structure not in ("BULL", "BEAR"):
            self.assertNotEqual(ev.long.setup_type, "TREND_PULLBACK")
            self.assertNotEqual(ev.short.setup_type, "TREND_PULLBACK")


if __name__ == "__main__":
    unittest.main()

class AdaptiveV12Tests(unittest.TestCase):
    def test_collapsing_breadth_blocks_long_when_btc_is_weak(self):
        cfg = AppConfig().trading
        c5 = trend_candles(100, 100, 0.05, 300_000)
        c15 = compression_breakout_15m(80)
        c30 = trend_candles(100, 90, 0.18, 1_800_000)
        c1h = trend_candles(100, 80, 0.30, 3_600_000)
        c4h = trend_candles(80, 60, 0.70, 14_400_000)
        price = c15[-1].close
        btc_features = {
            "ret_1h_1": -0.8, "ret_1h_4": -0.5, "ret_4h_1": 0.2,
            "ema20_gap_1h_pct": 0.1, "ema50_gap_4h_pct": 0.8,
            "ema20_slope_4h_pct": 0.1, "atr_15m_pct": 0.4, "adx_1h": 30,
        }
        ev = evaluate_symbol(
            "SOLUSDT", c5=c5, c15=c15, c30=c30, c1h=c1h, c4h=c4h,
            bid=price * 0.9998, ask=price * 1.0002, funding_8h=0.0, book_bid_share=0.55,
            btc_features=btc_features, regime="BULL", breadth_1h=0.55, breadth_4h=0.90,
            universe_return_1h=-0.4, universe_return_4h=0.1, cfg=cfg,
            breadth_change_15m=-0.08, breadth_change_1h=-0.25, breadth_state="FALLING_FAST",
            btc_shock=False,
        )
        self.assertTrue(any("market breadth collapsing" in x for x in ev.long.hard_blockers), ev.long.hard_blockers)

    def test_intraday_bear_transition_allowed_inside_bull_4h(self):
        cfg = AppConfig().trading
        c5 = trend_candles(100, 120, -0.04, 300_000)
        c15 = trend_candles(100, 120, -0.10, 900_000)
        c30 = trend_candles(100, 130, -0.16, 1_800_000)
        c1h = trend_candles(100, 150, -0.28, 3_600_000)
        c4h = trend_candles(80, 80, 0.55, 14_400_000)
        price = c15[-1].close
        btc_features = {
            "ret_1h_1": -0.5, "ret_1h_4": -0.7, "ret_4h_1": 0.4,
            "ema20_gap_1h_pct": -0.3, "ema50_gap_4h_pct": 1.0,
            "ema20_slope_4h_pct": 0.2, "atr_15m_pct": 0.4, "adx_1h": 30,
        }
        ev = evaluate_symbol(
            "XRPUSDT", c5=c5, c15=c15, c30=c30, c1h=c1h, c4h=c4h,
            bid=price * 0.9998, ask=price * 1.0002, funding_8h=0.0, book_bid_share=0.45,
            btc_features=btc_features, regime="BULL", breadth_1h=0.45, breadth_4h=0.90,
            universe_return_1h=-0.3, universe_return_4h=-0.5, cfg=cfg,
            breadth_change_15m=-0.05, breadth_change_1h=-0.18, breadth_state="FALLING_FAST",
            btc_shock=False,
        )
        self.assertEqual(ev.parent_structure, "TRANSITION_BEAR")
        self.assertFalse(any("SHORT conflicts" in x for x in ev.short.hard_blockers), ev.short.hard_blockers)
