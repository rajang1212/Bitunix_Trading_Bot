import tempfile
import unittest
from pathlib import Path

from config import AppConfig
from store import DayTraderStore
import multiagent


def record(cid="M1", direction="LONG", entry=100.0, margin=500.0):
    return {
        "client_id":cid,"symbol":"BTCUSDT","direction":direction,"status":"PAPER_OPEN",
        "opened_utc":"2026-09-23T00:00:00+00:00","entry_price":entry,"stop_price":90.0 if direction=="LONG" else 110.0,
        "initial_stop_price":90.0 if direction=="LONG" else 110.0,"reference_target_price":120.0 if direction=="LONG" else 80.0,
        "partial_target_price":115.0 if direction=="LONG" else 85.0,"qty":margin*5/entry,"initial_qty":margin*5/entry,
        "remaining_fraction":1.0,"leverage":5,"margin_usdt":margin,"rule_score":80.0,"setup_type":"TEST","market_regime":"BULL",
        "features":{},"reasons":[],"best_price":entry,"trade_type":"DAY","agent_name":"DAY_AGENT","notional_usdt":margin*5,
        "max_hold_minutes":999999,"partial_take_profit_r":2.0,"partial_fraction":0.5,"runner_lock_r":0.1,"strategy_version":"1.7.1",
    }


class FakeClient:
    def __init__(self, mark): self.mark=mark
    def tickers_for(self, symbols):
        return [{"symbol":s,"markPrice":self.mark} for s in symbols]


class ManualCloseExecutionTests(unittest.TestCase):
    def test_manual_market_closes_and_settles_reserve(self):
        cfg=AppConfig()
        with tempfile.TemporaryDirectory() as td:
            st=DayTraderStore(Path(td)/"db.sqlite3")
            try:
                st.ensure_wallet()
                st.insert_trade(record())
                st.set_manual_exit("M1","MARKET")
                before=st.wallet_state()["reserve_balance"]
                multiagent._monitor_positions(FakeClient(105.0),st,cfg)
                self.assertIsNone(st.active_trade("M1"))
                row=st.db.execute("SELECT close_reason,close_price,net_pnl FROM trades WHERE client_id='M1'").fetchone()
                self.assertEqual(row[0],"MANUAL_MARKET")
                self.assertAlmostEqual(float(row[1]),105.0)
                self.assertAlmostEqual(st.wallet_state()["reserve_balance"],before+float(row[2]))
            finally: st.close()

    def test_manual_limit_waits_then_closes_at_limit(self):
        cfg=AppConfig()
        with tempfile.TemporaryDirectory() as td:
            st=DayTraderStore(Path(td)/"db.sqlite3")
            try:
                st.ensure_wallet()
                st.insert_trade(record())
                st.set_manual_exit("M1","LIMIT",108.0)
                multiagent._monitor_positions(FakeClient(107.0),st,cfg)
                self.assertIsNotNone(st.active_trade("M1"))
                multiagent._monitor_positions(FakeClient(109.0),st,cfg)
                self.assertIsNone(st.active_trade("M1"))
                row=st.db.execute("SELECT close_reason,close_price FROM trades WHERE client_id='M1'").fetchone()
                self.assertEqual(row[0],"MANUAL_LIMIT")
                self.assertAlmostEqual(float(row[1]),108.0)
            finally: st.close()


if __name__ == '__main__':
    unittest.main()
