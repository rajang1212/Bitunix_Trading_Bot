import unittest

from daytrader import _performance_summary


class PerformanceSummaryTests(unittest.TestCase):
    def test_summary_counts_and_profit_factor(self):
        rows = [
            {"net_pnl": 100.0},
            {"net_pnl": -40.0},
            {"net_pnl": 20.0},
        ]
        s = _performance_summary(rows, opened=4)
        self.assertEqual(s["opened"], 4)
        self.assertEqual(s["closed"], 3)
        self.assertEqual(s["wins"], 2)
        self.assertEqual(s["losses"], 1)
        self.assertAlmostEqual(s["net"], 80.0)
        self.assertAlmostEqual(s["win_rate"], 200.0 / 3.0)
        self.assertAlmostEqual(s["profit_factor"], 3.0)
        self.assertAlmostEqual(s["best"], 100.0)
        self.assertAlmostEqual(s["worst"], -40.0)


if __name__ == "__main__":
    unittest.main()
