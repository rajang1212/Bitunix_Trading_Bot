import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from store import DayTraderStore


class StoreTests(unittest.TestCase):
    def test_trade_roundtrip(self):
        with tempfile.TemporaryDirectory() as td:
            s = DayTraderStore(Path(td) / "db.sqlite3")
            try:
                s.insert_trade({
                    "client_id": "PAPER-X", "symbol": "BTCUSDT", "direction": "LONG", "opened_utc": "2026-01-01T00:00:00+00:00",
                    "entry_price": 100.0, "stop_price": 98.0, "initial_stop_price": 98.0,
                    "reference_target_price": 105.0, "partial_target_price": 104.0,
                    "qty": 25.0, "initial_qty": 25.0, "remaining_fraction": 1.0, "leverage": 5,
                    "margin_usdt": 500.0, "rule_score": 72, "setup_type": "TREND_PULLBACK",
                    "market_regime": "BULL", "features": {}, "reasons": [], "best_price": 100.0,
                })
                self.assertTrue(s.active_for_symbol("BTCUSDT"))
                s.update_trade("PAPER-X", status="PAPER_CLOSED", closed_utc="2026-01-01T02:00:00+00:00", net_pnl=25.0)
                self.assertFalse(s.active_for_symbol("BTCUSDT"))
            finally:
                s.close()

    def test_swing_learning_and_trade_type_schema(self):
        with tempfile.TemporaryDirectory() as td:
            s = DayTraderStore(Path(td) / "db.sqlite3")
            try:
                sid = s.insert_swing_snapshot(
                    candle_time_ms=1700000000000, symbol="ETHUSDT", price=2000.0, spread_pct=0.02,
                    market_regime="BULL", rule_long_score=78.0, rule_short_score=20.0,
                    best_direction="LONG", best_setup="SWING_PULLBACK", features={"x": 1.0}, ai=None,
                )
                s.insert_swing_learning_example(
                    snapshot_id=sid, symbol="ETHUSDT", direction="LONG", candle_time_ms=1700000000000,
                    entry_price=2000.0, stop_pct=4.0, target_r=3.0, rule_score=78.0,
                    setup_type="SWING_PULLBACK", features={"x": 1.0},
                )
                self.assertEqual(s.swing_learning_counts()["pending"], 1)
                s.insert_trade({
                    "client_id": "PAPER-SWING-X", "symbol": "ETHUSDT", "direction": "LONG",
                    "opened_utc": "2026-01-01T00:00:00+00:00", "entry_price": 2000.0, "stop_price": 1920.0,
                    "initial_stop_price": 1920.0, "reference_target_price": 2240.0, "partial_target_price": 2160.0,
                    "qty": 1.0, "initial_qty": 1.0, "remaining_fraction": 1.0, "leverage": 2.0,
                    "margin_usdt": 1000.0, "notional_usdt": 2000.0, "rule_score": 78.0,
                    "setup_type": "SWING_PULLBACK", "market_regime": "BULL", "features": {}, "reasons": [],
                    "best_price": 2000.0, "trade_type": "SWING", "agent_name": "SWING_AGENT",
                    "max_hold_minutes": 10080, "partial_take_profit_r": 2.0, "partial_fraction": 0.5,
                    "runner_lock_r": 0.5, "strategy_version": "1.3.1",
                })
                self.assertEqual(len(s.active_by_type("SWING")), 1)
            finally:
                s.close()


if __name__ == "__main__":
    unittest.main()
