import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from config import AppConfig
from governor import PortfolioGovernor, Proposal, planned_notional_and_risk
from indicators import Candle, ema
from swing_strategy import evaluate_swing_symbol, build_swing_trade_plan
from multiagent import _apply_swing_loss_recovery, _paper_stop_fill_price
from datetime import datetime, timezone


def trend(n, start, step, interval_ms):
    out=[]; p=start; base=1_700_000_000_000
    for i in range(n):
        o=p; c=p+step; wig=max(abs(step)*0.8,0.12)
        out.append(Candle(o,max(o,c)+wig,min(o,c)-wig,c,1000+i,100000+i*100,base+i*interval_ms)); p=c
    return out


def bullish_pullback_1h():
    out=trend(96,100,0.35,3_600_000)
    # Retrace several hours toward EMA20, then strong resumption candle.
    p=out[-1].close; base=out[-1].time_ms+3_600_000
    for i,delta in enumerate((-0.9,-0.8,-0.65,-0.45)):
        o=p; c=p+delta; out.append(Candle(o,max(o,c)+0.25,min(o,c)-0.30,c,1300,150000,base+i*3_600_000)); p=c
    e20=ema([c.close for c in out],20)
    # Place a candle into the EMA zone if needed.
    o=p; low=min(p,e20)-0.15; c=max(e20+0.20,p+0.45)
    out.append(Candle(o,c+0.25,low,c,2200,260000,base+4*3_600_000)); p=c
    # Strong confirmation above previous high.
    prev=out[-1]; o=p; c=prev.high+0.55
    out.append(Candle(o,c+0.20,o-0.10,c,2600,300000,base+5*3_600_000))
    return out


def bearish_pullback_1h():
    out=trend(96,150,-0.35,3_600_000)
    p=out[-1].close; base=out[-1].time_ms+3_600_000
    for i,delta in enumerate((0.9,0.8,0.65,0.45)):
        o=p; c=p+delta; out.append(Candle(o,max(o,c)+0.30,min(o,c)-0.25,c,1300,150000,base+i*3_600_000)); p=c
    e20=ema([c.close for c in out],20)
    o=p; high=max(p,e20)+0.15; c=min(e20-0.20,p-0.45)
    out.append(Candle(o,high,c-0.25,c,2200,260000,base+4*3_600_000)); p=c
    prev=out[-1]; o=p; c=prev.low-0.55
    out.append(Candle(o,o+0.10,c-0.20,c,2600,300000,base+5*3_600_000))
    return out


class SwingAgentTests(unittest.TestCase):
    def test_swing_long_can_qualify(self):
        cfg=AppConfig().swing
        c1h=bullish_pullback_1h()
        c4h=trend(100,70,0.65,14_400_000)
        c1d=trend(90,35,1.15,86_400_000)
        price=c1h[-1].close
        cand=evaluate_swing_symbol(
            'SOLUSDT',c1h=c1h,c4h=c4h,c1d=c1d,bid=price*.9998,ask=price*1.0002,
            funding_8h=0.0001,book_bid_share=.55,btc_ret_4h=.7,btc_ret_1d=1.2,
            universe_return_4h=.5,regime='BULL',cfg=cfg,
        )
        self.assertEqual(cand.parent_structure,'BULL')
        self.assertGreaterEqual(cand.long.score,cfg.minimum_rule_score)
        self.assertFalse(cand.long.hard_blockers,cand.long.hard_blockers)
        self.assertIsNotNone(build_swing_trade_plan(cand,cfg))

    def test_bull_market_correction_is_shadow_only(self):
        cfg=AppConfig().swing
        c1h=bearish_pullback_1h()
        c4h=trend(100,180,-0.65,14_400_000)
        c1d=trend(90,35,1.15,86_400_000)
        price=c1h[-1].close
        cand=evaluate_swing_symbol(
            'ETHUSDT',c1h=c1h,c4h=c4h,c1d=c1d,bid=price*.9998,ask=price*1.0002,
            funding_8h=0,book_bid_share=.45,btc_ret_4h=-.6,btc_ret_1d=1.2,
            universe_return_4h=-.4,regime='BEAR',cfg=cfg,
            breadth_1h=.25,breadth_4h=.30,breadth_change_1h=-.20,
        )
        self.assertEqual(cand.parent_structure,'TRANSITION_BEAR')
        self.assertEqual(cand.features['correction_bear'],1.0)
        self.assertGreaterEqual(cand.features['correction_shadow_short_score'],cfg.minimum_rule_score)
        self.assertTrue(any('shadow-only' in x for x in cand.short.hard_blockers))
        self.assertIsNone(build_swing_trade_plan(cand,cfg))

    def test_swing_bear_parent_blocks_long(self):
        cfg=AppConfig().swing
        c1h=trend(100,150,-0.35,3_600_000); c4h=trend(100,180,-0.65,14_400_000); c1d=trend(90,230,-1.15,86_400_000); price=c1h[-1].close
        cand=evaluate_swing_symbol('XRPUSDT',c1h=c1h,c4h=c4h,c1d=c1d,bid=price*.9998,ask=price*1.0002,funding_8h=0,book_bid_share=.45,btc_ret_4h=-.6,btc_ret_1d=-1,universe_return_4h=-.4,regime='BEAR',cfg=cfg)
        self.assertEqual(cand.parent_structure,'BEAR')
        self.assertTrue(any('countertrend LONG' in x for x in cand.long.hard_blockers))


class DefensiveSwingTests(unittest.TestCase):
    def test_transition_bear_never_opens_active_trade(self):
        cfg=AppConfig().swing
        c1h=bearish_pullback_1h(); c4h=trend(100,180,-0.65,14_400_000); c1d=trend(90,35,1.15,86_400_000); price=c1h[-1].close
        cand=evaluate_swing_symbol('ETHUSDT',c1h=c1h,c4h=c4h,c1d=c1d,bid=price*.9998,ask=price*1.0002,funding_8h=0,book_bid_share=.45,btc_ret_4h=-.6,btc_ret_1d=1.2,universe_return_4h=-.4,regime='MIXED',cfg=cfg)
        self.assertEqual(cand.parent_structure,'TRANSITION_BEAR')
        self.assertTrue(any('DEFENSIVE' in x for x in cand.short.hard_blockers))
        self.assertIsNone(build_swing_trade_plan(cand,cfg))

    def test_v182_safety_defaults(self):
        cfg=AppConfig()
        self.assertEqual(cfg.swing.max_new_positions_per_scan,1)
        self.assertEqual(cfg.governor.daily_realized_loss_limit_usdt,350.0)
        self.assertEqual(cfg.swing.second_loss_risk_multiplier,0.5)
        self.assertTrue(cfg.swing.correction_shadow_only)


class GovernorTests(unittest.TestCase):
    def test_swing_notional_is_risk_sized(self):
        cfg=AppConfig()
        class P: pass
        p=P(); p.reference_target_price=110; p.entry_price=100; p.setup_type='X'; p.regime='BULL'; p.features={}; p.reasons=[]
        proposal=Proposal('SWING','SOLUSDT','LONG',80,2.5,6.0,p)
        notional,lev,risk=planned_notional_and_risk(proposal,cfg)
        self.assertLessEqual(notional,cfg.swing.paper_margin_usdt*cfg.swing.leverage+1e-9)
        self.assertLessEqual(risk,cfg.swing.max_risk_per_trade_usdt+1e-6)
        self.assertEqual(lev,5.0)
        self.assertLessEqual(notional/lev,cfg.swing.paper_margin_usdt+1e-9)


    def test_swing_capacity_is_seven_with_default_same_direction_cap_six(self):
        cfg=AppConfig()
        self.assertEqual(cfg.governor.max_swing_positions,7)
        self.assertEqual(cfg.swing.max_same_direction_positions,6)

    def test_same_direction_cap_can_be_set_to_seven(self):
        cfg=AppConfig(); cfg.swing.max_same_direction_positions=7
        self.assertEqual(cfg.swing.max_same_direction_positions,7)

    def test_governor_enforces_five_day_slots(self):
        cfg=AppConfig(); gov=PortfolioGovernor(cfg)
        active=[{'trade_type':'DAY','symbol':f'C{i}','direction':'LONG','entry_price':100,'stop_price':99,'margin_usdt':500,'leverage':5,'remaining_fraction':1} for i in range(5)]
        class P: pass
        p=P(); prop=Proposal('DAY','NEW','LONG',80,2,1,p)
        ok,why=gov.basic_allow(prop,active,0,0,0,0)
        self.assertFalse(ok); self.assertIn('DAY slot cap',why)


if __name__=='__main__': unittest.main()

class V182RiskControlTests(unittest.TestCase):
    def test_paper_stop_fill_uses_resident_stop_price(self):
        self.assertEqual(_paper_stop_fill_price("LONG", 95.0, 90.0), 95.0)
        self.assertEqual(_paper_stop_fill_price("SHORT", 105.0, 110.0), 105.0)

    def test_second_direction_loss_halves_new_swing_risk(self):
        cfg=AppConfig()
        class FakeStore:
            def consecutive_losses_by_type_direction(self, trade_type, direction): return 2
            def latest_closed_time_by_type_direction(self, trade_type, direction): return datetime.now(timezone.utc).isoformat()
        class P: pass
        plan=P(); prop=Proposal('SWING','SOLUSDT','LONG',80,2.5,2.0,plan)
        ok,reason=_apply_swing_loss_recovery(FakeStore(),prop,cfg,{"swing_active":[]},datetime.now(timezone.utc))
        self.assertTrue(ok,reason)
        self.assertEqual(prop.risk_multiplier,0.5)
        _n,_l,risk=planned_notional_and_risk(prop,cfg)
        self.assertLessEqual(risk,50.0+1e-6)

    def test_recovery_mode_allows_only_one_same_direction_position(self):
        cfg=AppConfig()
        class FakeStore:
            def consecutive_losses_by_type_direction(self, trade_type, direction): return 2
            def latest_closed_time_by_type_direction(self, trade_type, direction): return datetime.now(timezone.utc).isoformat()
        class P: pass
        prop=Proposal('SWING','SOLUSDT','LONG',80,2.5,2.0,P())
        state={"swing_active":[{"direction":"LONG"}]}
        ok,reason=_apply_swing_loss_recovery(FakeStore(),prop,cfg,state,datetime.now(timezone.utc))
        self.assertFalse(ok)
        self.assertIn('recovery mode cap',reason)


class MarketDataKeyRegressionTests(unittest.TestCase):
    def test_market_data_uses_strategy_cache_keys(self):
        from unittest.mock import patch
        import multiagent

        def fake_candles(client, symbol, interval, limit):
            return [interval]

        with patch.object(multiagent, '_candles', side_effect=fake_candles), \
             patch.object(multiagent, '_closed', side_effect=lambda rows, interval: rows), \
             patch.object(multiagent, '_depth', return_value=(100.0, 100.1, 0.55)), \
             patch.object(multiagent.time, 'sleep', return_value=None):
            data = multiagent._market_data(object(), 'BTCUSDT')

        self.assertEqual(set(('c5','c15','c30','c1h','c4h','c1d','bid','ask','book')) - set(data), set())
        self.assertNotIn('c5m', data)
        self.assertNotIn('c15m', data)
        self.assertNotIn('c30m', data)
        self.assertEqual(data['c5'], ['5m'])
        self.assertEqual(data['c15'], ['15m'])
        self.assertEqual(data['c30'], ['30m'])
